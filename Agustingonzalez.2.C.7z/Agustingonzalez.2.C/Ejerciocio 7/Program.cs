using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejerciocio_7
{
  class Program
  {
    static void Main(string[] args)
    {
      DateTime año;
      DateTime dateTime;
      dateTime = DateTime.Now;
      TimeSpan dif;
      int contador = 0;

      Console.WriteLine("Ingrese su fecha de nacimiento");
      año = DateTime.Parse(Console.ReadLine());
      dif = dateTime - año;
      
      for (int i = año.Year - 1; i <= dateTime.Year; i++)
      {
        if ((i % 4) == 0)
        {
          if (((i % 400) == 0 && (i % 100) == 0) || (i % 100) != 0)
            contador++;
        }
      }
      dif += (TimeSpan.FromDays(contador));
      Console.WriteLine("Vivio {0} dias", dif.Days);
      Console.ReadKey();
    }
  }
}

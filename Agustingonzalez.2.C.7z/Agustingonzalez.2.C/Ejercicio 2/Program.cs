﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            float num, cuadrado, cubo;
            Console.WriteLine("Ingrese un numero");
            num = float.Parse(Console.ReadLine());
            while(num < 0)
            {
                Console.WriteLine("ERROR, Reingrese numero");
                num = float.Parse(Console.ReadLine());
            }
            cuadrado =(float) Math.Pow(num, 2);
            cubo = (float)Math.Pow(num, 3);
            Console.WriteLine("El numero es {0} \nEl cuadrado es {1} \nEl cubo es {2}", num, cuadrado, cubo);
            Console.ReadKey();
        }
    }
}

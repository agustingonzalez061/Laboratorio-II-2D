﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejerciocio_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num,i;
            int contador = 0;
            int acumulador = 0;
            int min = 0;
            int max = 0;
            float promedio;
            int otro;
            bool vali;

            for (i = 0; i < 5;i ++)
            {
                Console.WriteLine("Ingrese un numero");
                vali = int.TryParse(Console.ReadLine(), out otro);
                if (vali == true)
                {
                    num = otro;
                acumulador = acumulador + num;
                if(i == 0)
                {
                    min = num;
                    max = num;
                }
                if(min > num)
                {
                    min = num;
                }
                if(max < num)
                {
                    max = num;
                }
                }

            }
                promedio = acumulador / (float)i;
                Console.WriteLine("La suma es : {0}", acumulador);
                Console.WriteLine("El minimo es: {0}", min);
                Console.WriteLine("El maximo es: {0}", max);
                Console.WriteLine("El promedio es: {0:#,#.00}", promedio);

                Console.ReadLine();
            {

            }
        }
    }
}

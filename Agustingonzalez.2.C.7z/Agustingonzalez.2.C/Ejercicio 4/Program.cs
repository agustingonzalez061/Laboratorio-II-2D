using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
  class Program
  {
    static void Main(string[] args)
    {
      int perfectos = 0;
      int numero = 1;
      int acumulador;
      int i;

      do
      {
        acumulador = 0;
        for(i = numero -1;i > 0; i --)
        {
          if((numero % i ) == 0)
          {
            acumulador += i;

            if(acumulador>numero)
            {
              break;
            }
          }
        }
        if(acumulador == numero)
        {
          perfectos++;
          Console.WriteLine("Perfecto encontrado {0}", numero);
        }
        numero++;
      } while (perfectos < 4);
      Console.ReadKey();
    }
  }
}

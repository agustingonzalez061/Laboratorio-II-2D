using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_5
{
  class Program
  {
    static void Main(string[] args)
    {
      int num,i,n,acumulador = 0,acumuladorDos =0;
      Console.WriteLine("Ingrese un numero");
      if (int.TryParse(Console.ReadLine(), out num))
      {
        for (int dato = 1; dato < num; dato++)
        {
          acumulador = 0;
          acumuladorDos = 0;
          for (i = dato - 1; i > 0; i--)
          {
            acumulador += i;
          }
          for (n = dato + 1; n < acumulador; n++)
          {
            acumuladorDos += n;
            if (acumulador == acumuladorDos)
            {
              Console.WriteLine("{0} Es centro numerico",dato);
              break;
            }
          }
        }
        Console.ReadKey();
      }
    }
  }
}
